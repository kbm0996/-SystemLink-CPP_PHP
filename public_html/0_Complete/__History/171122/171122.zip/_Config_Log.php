<?php
$g_LogLevel = 0;

// dfLOG_LEVEL_DEBUG	0
// dfLOG_LEVEL_WARNING	1
// dfLOG_LEVEL_SYSTEM	2
?>