<?php
$g_DB_IP = "127.0.0.1";
$g_DB_ID = "root";
$g_DB_PASS = "1234";
$g_DB_NAME = "log_schema";
$g_DB_PORT = 3306;

/*
CREATE SCHEMA `log_schema` DEFAULT CHARACTER SET utf8;

USE log_schema;

/////////////////////////////////////////////////
// SystemLog Table Info
/////////////////////////////////////////////////

CREATE TABLE `systemlog_template` (
	`no` BIGINT primary key not null auto_increment,
	`date` DATETIME not null,
	`accountno` VARCHAR(45) not null,
	`action` TEXT default null,
	`message` TEXT default null
);
*/
?>