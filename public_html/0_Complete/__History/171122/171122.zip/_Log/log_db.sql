CREATE SCHEMA `log_schema` DEFAULT CHARACTER SET utf8;

USE log_schema;

CREATE TABLE `systemlog_template` (
	`no` BIGINT primary key not null auto_increment,
	`date` DATETIME not null,
	`accountno` VARCHAR(45) not null,
	`action` TEXT default null,
	`message` TEXT default null
);