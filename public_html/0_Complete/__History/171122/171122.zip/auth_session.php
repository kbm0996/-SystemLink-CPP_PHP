<?php
include "_LIB/lib_DB.php";
include "_LIB/lib_Key.php";

DB_Connect();

/*---------------------------------------------
	Request Param - accountno, sessionkey
	Response Param - resultcode, accountno, new_sessionkey
---------------------------------------------*/

if(!isset($_GET['accountno']) || !isset($_GET['sessionkey']))
	exit;

$accountno		= mysqli_real_escape_string($g_DB, $_GET['accountno']);
$sessionkey		= mysqli_real_escape_string($g_DB, $_GET['sessionkey']);


$Query = "SELECT COUNT(accountno) AS Cnt FROM session WHERE accountno = '{$accountno}' AND sessionkey = '{$sessionkey}' AND UNIX_TIMESTAMP(NOW()) > regtime + 300"; // 세션 갱신 시간 5분 (300초)
$Result		= DB_ExecQuery($Query);

$Session	= mysqli_fetch_array($Result, MYSQL_ASSOC);
mysqli_free_result($Result);

if($Session['Cnt'] == 0)
{
	$resultcode = false;
	$accountno = null;
	$new_sessionkey = null;

	echo "Searching Session Failed <br>";
}
else
{
	$resultCode = true;
	$new_sessionkey = KeyGen32();

	$arrQry = array();

	$Query		= "INSERT INTO session (accountno, sessionkey, regtime) VALUES ({$accountno}, '{$new_sessionkey}', UNIX_TIMESTAMP(NOW())) ON DUPLICATE KEY UPDATE sessionkey = '{$new_sessionkey}', regtime=UNIX_TIMESTAMP(NOW())";
	array_push($arrQry, $Query);
	
	$accountno = DB_TransactionQuery($arrQry);

	echo "SessionKey : " . $sessionkey . " → ". $new_sessionkey ." Updating Session Success <br>";
}

DB_Disconnect();
?>