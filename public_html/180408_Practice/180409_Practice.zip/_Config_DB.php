<?php
$g_DB_IP = "127.0.0.1";
$g_DB_ID = "root";
$g_DB_PASS = "1234";
$g_DB_NAME = "game_schema";
$g_DB_PORT = 3306;
?>